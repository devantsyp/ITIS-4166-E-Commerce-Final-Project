import prisma from "../config/db.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

import {
  getAllUsers,
  getUserById,
  getLoggedInUser,
  deleteCurrentUser,
  updateCurrentUser,
} from "../services/userService.js";

export async function getAllUsersHandler(req, res, next) {
  try {
    const users = await getAllUsers();
    res.status(200).json(users);
  } catch (err) {
    next(err);
  }
}

export async function getUserByIdHandler(req, res, next) {
  try {
    const users = await getUserById(Number(req.params.id));
    res.status(200).json(users);
  } catch (err) {
    next(err);
  }
}

export async function getCurrentUserHandler(req, res, next) {
  try {
    const user = await getLoggedInUser();
    res.status(200).json(user);
  } catch (err) {
    next(err);
  }
}
